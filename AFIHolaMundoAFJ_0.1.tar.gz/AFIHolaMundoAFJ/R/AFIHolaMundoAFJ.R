#' Title Imprimir por pantalla Hola Mundo (Spanish) 
#'
#' @return Null
#' @export 
#'
#' @examples HolaMundo()
#' @export 
HolaMundo<-function(){
  print('Hola Mundo')
}



#' Title Imprimir por pantalla HelloWorld (English)
#'
#' @return Null
#' 
#'
#' @examples HelloWorld() 
#' @export 
HelloWorld<-function(){
  print('Hello World')
}
